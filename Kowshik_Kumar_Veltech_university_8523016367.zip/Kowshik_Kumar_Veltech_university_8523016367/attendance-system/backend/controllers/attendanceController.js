const Attendance = require('../models/Attendance');

// Helper function to calculate total hours between two time strings
const calculateHours = (start, end) => {
    const startTime = new Date(`2026-01-01 ${start}`);
    const endTime = new Date(`2026-01-01 ${end}`);
    const diff = (endTime - startTime) / 1000 / 60 / 60; // Convert to hours
    return diff > 0 ? diff.toFixed(2) : 0;
};

exports.checkIn = async (req, res) => {
    try {
        const userId = req.user.id; 
        const date = new Date().toISOString().split('T')[0]; 
        const now = new Date();

        const existing = await Attendance.findOne({ userId, date });
        if (existing) return res.status(400).json({ message: "Already checked in today" });

        // Logic for "Late" status: If check-in is after 9:30 AM
        const checkInTime = now.toLocaleTimeString();
        let status = 'Present';
        if (now.getHours() > 9 || (now.getHours() === 9 && now.getMinutes() > 30)) {
            status = 'Late';
        }

        const newRecord = new Attendance({
            userId,
            date,
            checkInTime,
            status
        });

        await newRecord.save();
        res.status(201).json({ message: "Checked in successfully", data: newRecord });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

exports.checkOut = async (req, res) => {
    try {
        const userId = req.user.id;
        const date = new Date().toISOString().split('T')[0];

        const record = await Attendance.findOne({ userId, date });
        if (!record) return res.status(404).json({ message: "No check-in record found for today" });

        const checkOutTime = new Date().toLocaleTimeString();
        record.checkOutTime = checkOutTime;
        
        // Calculate Total Hours Worked
        record.totalHours = calculateHours(record.checkInTime, checkOutTime);
      
        await record.save();
        res.status(200).json({ message: "Checked out successfully", data: record });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

// GET /api/attendance/my-summary
exports.getMySummary = async (req, res) => {
    try {
        const history = await Attendance.find({ userId: req.user.id });
        const summary = {
            present: history.filter(r => r.status === 'Present').length,
            late: history.filter(r => r.status === 'Late').length,
            halfDay: history.filter(r => r.status === 'Half Day').length,
            totalHours: history.reduce((acc, curr) => acc + (Number(curr.totalHours) || 0), 0).toFixed(2)
        };
        res.status(200).json({ success: true, data: summary });
    } catch (error) {
        res.status(500).json({ message: "Error fetching summary", error: error.message });
    }
};

exports.getMyHistory = async (req, res) => {
    try {
        const history = await Attendance.find({ userId: req.user.id }).sort({ date: -1 });
        res.status(200).json({ data: history });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

// Manager: View All with Filters
exports.getAllAttendance = async (req, res) => {
    try {
        const { status, date } = req.query; // Get filter params from URL
        let query = {};
        
        if (status) query.status = status;
        if (date) query.date = date;

        const allData = await Attendance.find(query)
            .populate('userId', 'name email department employeeId')
            .sort({ date: -1 });
            
        res.status(200).json({ data: allData });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};