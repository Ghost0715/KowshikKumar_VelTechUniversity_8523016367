const mongoose = require('mongoose');
const User = require('./models/User'); 
const Attendance = require('./models/Attendance');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const seedDB = async () => {
    try {
        const uri = process.env.MONGODB_URI;
        if (!uri) throw new Error("MONGODB_URI is not defined in .env");

        console.log("Connecting to MongoDB...");
        await mongoose.connect(uri);
        
        console.log("Cleaning old data...");
        await User.deleteMany({});
        await Attendance.deleteMany({});

        const hashedPassword = await bcrypt.hash('password123', 10);

        const users = await User.insertMany([
            { name: 'Kesir', email: 'kesir@test.com', password: hashedPassword, role: 'employee', department: 'Engineering', employeeId: 'EMP001' },
            { name: 'Manager Bob', email: 'manager@test.com', password: hashedPassword, role: 'manager', department: 'Management', employeeId: 'MGR001' },
            { name: 'Alice Smith', email: 'alice@test.com', password: hashedPassword, role: 'employee', department: 'HR', employeeId: 'EMP002' }
        ]);

        const attendanceRecords = [];
        for (let i = 0; i < 10; i++) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            
            attendanceRecords.push({
                userId: users[0]._id, 
                date: date.toISOString().split('T')[0],
                checkInTime: "09:15:00 AM",
                checkOutTime: "05:45:00 PM",
                status: 'present', 
                totalHours: "8.50" 
            });
        }

        await Attendance.insertMany(attendanceRecords);
        console.log("Database Seeded Successfully! 100% Ready.");
        process.exit();
    } catch (err) {
        console.error("Seeding Error:", err.message);
        process.exit(1);
    }
};

seedDB();