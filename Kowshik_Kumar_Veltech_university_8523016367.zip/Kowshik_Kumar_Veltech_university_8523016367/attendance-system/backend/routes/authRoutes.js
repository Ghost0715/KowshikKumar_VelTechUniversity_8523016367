const express = require('express');
const router = express.Router();
const { register, login, getMe } = require('../controllers/authController');
const { protect } = require('../middleware/authMiddleware'); // Import your protection middleware

// Public routes
router.post('/register', register);
router.post('/login', login);

// Private route: Get logged-in user's profile
// The 'protect' middleware ensures only users with a valid token can access this
router.get('/me', protect, getMe);

module.exports = router;