const express = require('express');
const router = express.Router();
const { 
    checkIn, 
    checkOut, 
    getMyHistory, 
    getAllAttendance 
} = require('../controllers/attendanceController');

const { protect, managerOnly } = require('../middleware/auth');

router.post('/checkin', protect, checkIn);
router.post('/checkout', protect, checkOut);
router.get('/my-history', protect, getMyHistory);

router.get('/all', protect, managerOnly, getAllAttendance);

module.exports = router;