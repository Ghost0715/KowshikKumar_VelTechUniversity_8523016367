const express = require('express');
const router = express.Router();
const { 
    checkIn, 
    checkOut, 
    getMyHistory, 
    getAllAttendance 
} = require('../controllers/attendanceController');

// Import the functions we exported in auth.js
const { protect, managerOnly } = require('../middleware/auth');

// Employee Routes
router.post('/checkin', protect, checkIn);
router.post('/checkout', protect, checkOut);
router.get('/my-history', protect, getMyHistory);

// Manager Routes
router.get('/all', protect, managerOnly, getAllAttendance);

module.exports = router;