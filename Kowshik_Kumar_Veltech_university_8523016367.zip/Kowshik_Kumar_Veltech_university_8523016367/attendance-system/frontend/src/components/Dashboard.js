import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Dashboard = () => {
    const [status, setStatus] = useState("Loading status...");
    const [history, setHistory] = useState([]);
    const [summary, setSummary] = useState({ present: 0, late: 0, halfDay: 0, totalHours: 0 });

    useEffect(() => {
        fetchHistory();
        fetchSummary();
    }, []);

    const fetchSummary = async () => {
        try {
            const token = localStorage.getItem('token');
            const res = await axios.get('http://localhost:5000/api/attendance/my-summary', {
                headers: { Authorization: `Bearer ${token}` }
            });
            if (res.data && res.data.data) {
                setSummary(res.data.data);
            }
        } catch (err) {
            console.error("Error fetching summary:", err);
        }
    };

    const fetchHistory = async () => {
        try {
            const token = localStorage.getItem('token');
            const res = await axios.get('http://localhost:5000/api/attendance/my-history', {
                headers: { Authorization: `Bearer ${token}` }
            });
            
            if (res.data && res.data.data) {
                setHistory(res.data.data);
                
                const today = new Date().toISOString().split('T')[0];
                const lastRecord = res.data.data[0]; 
                if (lastRecord && lastRecord.date === today) {
                    setStatus(lastRecord.checkOutTime ? "Work finished for today" : `Checked In at ${lastRecord.checkInTime}`);
                } else {
                    setStatus("Not Checked In");
                }
            }
        } catch (err) {
            console.error("Error fetching history:", err);
            setHistory([]); 
        }
    };

    const handleCheckIn = async () => {
        try {
            const token = localStorage.getItem('token');
            await axios.post('http://localhost:5000/api/attendance/checkin', {}, {
                headers: { Authorization: `Bearer ${token}` }
            });
            alert("Success: Checked In!");
            fetchHistory();
            fetchSummary();
        } catch (err) {
            alert(err.response?.data?.message || "Check-in failed");
        }
    };

    const handleCheckOut = async () => {
        try {
            const token = localStorage.getItem('token');
            await axios.post('http://localhost:5000/api/attendance/checkout', {}, {
                headers: { Authorization: `Bearer ${token}` }
            });
            alert("Success: Checked Out!");
            fetchHistory();
            fetchSummary();
        } catch (err) {
            alert(err.response?.data?.message || "Check-out failed");
        }
    };

    const handleLogout = () => {
        localStorage.clear();
        window.location.reload();
    };

    const getStatusColor = (status) => {
        switch (status) {
            case 'Present': return '#28a745';
            case 'Late': return '#ffc107';
            case 'Half Day': return '#fd7e14';
            case 'Absent': return '#dc3545';
            default: return '#555';
        }
    };

    return (
        <div style={{ textAlign: 'center', padding: '20px', fontFamily: 'Arial, sans-serif' }}>
            {/* Header Section with Profile and Logout Buttons */}
            <div style={{ overflow: 'auto', marginBottom: '20px' }}>
                <button 
                    onClick={handleLogout} 
                    style={{ float: 'right', padding: '8px 15px', cursor: 'pointer', backgroundColor: '#dc3545', color: 'white', border: 'none', borderRadius: '4px' }}
                >
                    Logout
                </button>
                <button 
                    onClick={() => window.location.href='/profile'} 
                    style={{ float: 'right', marginRight: '10px', padding: '8px 15px', cursor: 'pointer', backgroundColor: '#6c757d', color: 'white', border: 'none', borderRadius: '4px' }}
                >
                    My Profile
                </button>
            </div>

            <h1>Employee Dashboard</h1>

            {/* Monthly Summary Cards */}
            <div style={{ display: 'flex', justifyContent: 'center', gap: '20px', marginBottom: '30px' }}>
                <div style={{ border: '1px solid #ddd', padding: '15px', borderRadius: '8px', minWidth: '120px' }}>
                    <h4>Present</h4>
                    <p style={{ color: '#28a745', fontSize: '1.5rem', fontWeight: 'bold' }}>{summary.present}</p>
                </div>
                <div style={{ border: '1px solid #ddd', padding: '15px', borderRadius: '8px', minWidth: '120px' }}>
                    <h4>Late</h4>
                    <p style={{ color: '#ffc107', fontSize: '1.5rem', fontWeight: 'bold' }}>{summary.late}</p>
                </div>
                <div style={{ border: '1px solid #ddd', padding: '15px', borderRadius: '8px', minWidth: '120px' }}>
                    <h4>Total Hours</h4>
                    <p style={{ color: '#007bff', fontSize: '1.5rem', fontWeight: 'bold' }}>{summary.totalHours}h</p>
                </div>
            </div>
            
            <div style={{ marginBottom: '30px', border: '2px solid #ddd', padding: '20px', borderRadius: '10px', display: 'inline-block', minWidth: '350px' }}>
                <h3>Today's Status</h3>
                <p style={{ fontWeight: 'bold', fontSize: '1.2rem', color: '#555' }}>{status}</p>
                <button onClick={handleCheckIn} style={{ backgroundColor: '#28a745', color: 'white', padding: '10px 20px', border: 'none', borderRadius: '5px', cursor: 'pointer', marginRight: '10px' }}>Check In</button>
                <button onClick={handleCheckOut} style={{ backgroundColor: '#dc3545', color: 'white', padding: '10px 20px', border: 'none', borderRadius: '5px', cursor: 'pointer' }}>Check Out</button>
            </div>

            <h2>Your Attendance History</h2>
            <table border="1" style={{ margin: '20px auto', width: '90%', borderCollapse: 'collapse', boxShadow: '0 2px 5px rgba(0,0,0,0.1)' }}>
                <thead>
                    <tr style={{ backgroundColor: '#f8f9fa' }}>
                        <th style={{ padding: '12px' }}>Date</th>
                        <th style={{ padding: '12px' }}>Check In</th>
                        <th style={{ padding: '12px' }}>Check Out</th>
                        <th style={{ padding: '12px' }}>Total Hours</th>
                        <th style={{ padding: '12px' }}>Status</th>
                    </tr>
                </thead>
                <tbody>
                    {history?.length > 0 ? (
                        history.map((record, index) => (
                            <tr key={index}>
                                <td style={{ padding: '10px' }}>{new Date(record.date).toLocaleDateString()}</td>
                                <td style={{ padding: '10px' }}>{record.checkInTime || '-'}</td>
                                <td style={{ padding: '10px' }}>{record.checkOutTime || '-'}</td>
                                <td style={{ padding: '10px' }}>{record.totalHours ? `${record.totalHours}h` : '-'}</td>
                                <td style={{ padding: '10px', fontWeight: 'bold', color: getStatusColor(record.status) }}>
                                    {record.status}
                                </td>
                            </tr>
                        ))
                    ) : (
                        <tr><td colSpan="5" style={{ padding: '20px' }}>No records found.</td></tr>
                    )}
                </tbody>
            </table>
        </div>
    );
};

export default Dashboard;