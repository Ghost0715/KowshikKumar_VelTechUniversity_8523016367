import React, { useState } from 'react';
import axios from 'axios';

const Login = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:5000/api/auth/login', {
        email,
        password
      });
      
      localStorage.setItem('token', response.data.token);
      localStorage.setItem('role', response.data.role); 
      
      if (onLogin) {
        onLogin(response.data.token, response.data.role); 
      }

      if (response.data.role === 'manager') {
        console.log("Manager logged in successfully");
      } else {
        console.log("Employee logged in successfully");
      }
      
    } catch (error) {
      alert('Login Failed: ' + (error.response?.data?.message || 'Server Error'));
    }
  };

  return (
    <div style={{ 
      padding: '40px', 
      maxWidth: '400px', 
      margin: '100px auto', 
      textAlign: 'center', 
      border: '1px solid #ddd', 
      borderRadius: '10px',
      boxShadow: '0 4px 10px rgba(0,0,0,0.1)',
      fontFamily: 'Arial, sans-serif'
    }}>
      <h2 style={{ color: '#333', marginBottom: '20px' }}>Attendance System Login</h2>
      <p style={{ color: '#666', marginBottom: '20px' }}>Enter your credentials to access your dashboard</p>
      
      <form onSubmit={handleLogin}>
        <input 
          type="email" 
          placeholder="Email Address" 
          value={email} 
          onChange={(e) => setEmail(e.target.value)} 
          style={{ 
            display: 'block', 
            width: '100%', 
            padding: '12px', 
            marginBottom: '15px', 
            borderRadius: '5px', 
            border: '1px solid #ccc',
            boxSizing: 'border-box' 
          }}
          required 
        />
        <input 
          type="password" 
          placeholder="Password" 
          value={password} 
          onChange={(e) => setPassword(e.target.value)} 
          style={{ 
            display: 'block', 
            width: '100%', 
            padding: '12px', 
            marginBottom: '20px', 
            borderRadius: '5px', 
            border: '1px solid #ccc',
            boxSizing: 'border-box'
          }}
          required 
        />
        <button 
          type="submit" 
          style={{ 
            width: '100%', 
            padding: '12px', 
            backgroundColor: '#007bff', 
            color: 'white', 
            border: 'none', 
            borderRadius: '5px', 
            cursor: 'pointer',
            fontSize: '1rem',
            fontWeight: 'bold'
          }}
        >
          Login
        </button>
      </form>
    </div>
  );
};

export default Login;