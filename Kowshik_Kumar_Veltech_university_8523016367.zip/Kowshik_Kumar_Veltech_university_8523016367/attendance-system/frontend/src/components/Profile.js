import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Profile = () => {
    const [user, setUser] = useState(null);

    useEffect(() => {
        const fetchUserProfile = async () => {
            try {
                const token = localStorage.getItem('token');
               
                const res = await axios.get('http://localhost:5000/api/auth/me', {
                    headers: { Authorization: `Bearer ${token}` }
                });
                setUser(res.data.data);
            } catch (err) {
                console.error("Error fetching profile");
            }
        };
        fetchUserProfile();
    }, []);

    if (!user) return <div style={{ textAlign: 'center', marginTop: '50px' }}>Loading Profile...</div>;

    return (
        <div style={{ maxWidth: '500px', margin: '50px auto', padding: '20px', border: '1px solid #ddd', borderRadius: '10px', textAlign: 'center', boxShadow: '0 4px 8px rgba(0,0,0,0.1)' }}>
            <h1 style={{ color: '#333' }}>My Profile</h1>
            <div style={{ marginTop: '20px', fontSize: '1.1rem', lineHeight: '2' }}>
                <p><strong>Name:</strong> {user.name}</p>
                <p><strong>Email:</strong> {user.email}</p>
                <p><strong>Employee ID:</strong> {user.employeeId}</p>
                <p><strong>Department:</strong> {user.department}</p>
                <p><strong>Role:</strong> <span style={{ textTransform: 'capitalize' }}>{user.role}</span></p>
            </div>
            <button onClick={() => window.history.back()} style={{ marginTop: '20px', padding: '10px 20px', cursor: 'pointer', backgroundColor: '#6c757d', color: 'white', border: 'none', borderRadius: '5px' }}>
                Back to Dashboard
            </button>
        </div>
    );
};

export default Profile;