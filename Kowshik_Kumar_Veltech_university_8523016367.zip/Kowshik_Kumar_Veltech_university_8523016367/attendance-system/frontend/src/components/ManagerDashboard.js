import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ManagerDashboard = () => {
    const [allRecords, setAllRecords] = useState([]);
    const [filterName, setFilterName] = useState('');
    const [filterStatus, setFilterStatus] = useState('');
    const [filterDate, setFilterDate] = useState('');

    useEffect(() => {
        fetchAllAttendance();
    }, []);

    const fetchAllAttendance = async () => {
        try {
            const token = localStorage.getItem('token');
            const res = await axios.get('http://localhost:5000/api/attendance/all', {
                headers: { Authorization: `Bearer ${token}` }
            });
            if (res.data && res.data.data) {
                setAllRecords(res.data.data);
            }
        } catch (err) {
            console.error("Manager fetch error:", err);
        }
    };

    const exportToCSV = () => {
        const headers = ["Employee Name,Department,Date,Check In,Check Out,Status,Total Hours\n"];
        const rows = filteredRecords.map(r => 
            `${r.userId?.name},${r.userId?.department},${r.date},${r.checkInTime},${r.checkOutTime || 'Active'},${r.status},${r.totalHours || 0}`
        ).join("\n");
        
        const blob = new Blob([headers + rows], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `Attendance_Report_${new Date().toLocaleDateString()}.csv`;
        a.click();
    };

    const filteredRecords = allRecords.filter(record => {
        const matchesName = record.userId?.name.toLowerCase().includes(filterName.toLowerCase());
        const matchesStatus = filterStatus === '' || record.status === filterStatus;
        const matchesDate = filterDate === '' || record.date === filterDate;
        return matchesName && matchesStatus && matchesDate;
    });

    const handleLogout = () => {
        localStorage.clear();
        window.location.reload();
    };

    const getStatusColor = (status) => {
        switch (status) {
            case 'Present': return 'green';
            case 'Late': return '#ffc107'; 
            case 'Half Day': return 'orange';
            default: return 'red';
        }
    };

    return (
        <div style={{ padding: '20px', textAlign: 'center', fontFamily: 'Arial' }}>
            {/* Header Navigation Section */}
            <div style={{ overflow: 'auto', marginBottom: '20px' }}>
                <button onClick={handleLogout} style={{ float: 'right', padding: '10px', cursor: 'pointer', backgroundColor: '#dc3545', color: 'white', border: 'none', borderRadius: '4px' }}>Logout</button>
                <button 
                    onClick={() => window.location.href='/profile'} 
                    style={{ float: 'right', marginRight: '10px', padding: '10px', cursor: 'pointer', backgroundColor: '#6c757d', color: 'white', border: 'none', borderRadius: '4px' }}
                >
                    My Profile
                </button>
            </div>

            <h1>Manager Dashboard - All Employees</h1>

            {/* Manager Stats Cards */}
            <div style={{ display: 'flex', justifyContent: 'center', gap: '20px', marginBottom: '30px', flexWrap: 'wrap' }}>
                <div style={{ background: '#e3f2fd', padding: '15px', borderRadius: '8px', minWidth: '160px', border: '1px solid #2196f3' }}>
                    <h4 style={{ margin: '0', color: '#0d47a1' }}>Total Employees</h4>
                    <p style={{ fontSize: '1.8rem', fontWeight: 'bold', margin: '5px 0' }}>
                        {[...new Set(allRecords.map(r => r.userId?._id))].length}
                    </p>
                </div>
                <div style={{ background: '#e8f5e9', padding: '15px', borderRadius: '8px', minWidth: '160px', border: '1px solid #4caf50' }}>
                    <h4 style={{ margin: '0', color: '#1b5e20' }}>Today Present</h4>
                    <p style={{ fontSize: '1.8rem', fontWeight: 'bold', margin: '5px 0' }}>
                        {allRecords.filter(r => r.date === new Date().toISOString().split('T')[0]).length}
                    </p>
                </div>
                <div style={{ background: '#fff3e0', padding: '15px', borderRadius: '8px', minWidth: '160px', border: '1px solid #ff9800' }}>
                    <h4 style={{ margin: '0', color: '#e65100' }}>Departments</h4>
                    <p style={{ fontSize: '1.8rem', fontWeight: 'bold', margin: '5px 0' }}>
                        {[...new Set(allRecords.map(r => r.userId?.department))].length}
                    </p>
                </div>
            </div>

            {/* Filters Bar */}
            <div style={{ marginBottom: '20px', display: 'flex', justifyContent: 'center', gap: '10px', flexWrap: 'wrap' }}>
                <input 
                    type="text" 
                    placeholder="Search by Name..." 
                    value={filterName}
                    onChange={(e) => setFilterName(e.target.value)}
                    style={{ padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
                />
                <input 
                    type="date" 
                    value={filterDate}
                    onChange={(e) => setFilterDate(e.target.value)}
                    style={{ padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
                />
                <select onChange={(e) => setFilterStatus(e.target.value)} style={{ padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}>
                    <option value="">All Statuses</option>
                    <option value="Present">Present</option>
                    <option value="Late">Late</option>
                    <option value="Absent">Absent</option>
                    <option value="Half Day">Half Day</option>
                </select>
                <button onClick={exportToCSV} style={{ padding: '8px 15px', backgroundColor: '#007bff', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
                    Export CSV
                </button>
            </div>
            
            <table border="1" style={{ margin: '20px auto', width: '90%', borderCollapse: 'collapse', boxShadow: '0 2px 5px rgba(0,0,0,0.1)' }}>
                <thead>
                    <tr style={{ backgroundColor: '#f2f2f2' }}>
                        <th style={{ padding: '12px' }}>Employee Name</th>
                        <th style={{ padding: '12px' }}>Department</th>
                        <th style={{ padding: '12px' }}>Date</th>
                        <th style={{ padding: '12px' }}>Check In</th>
                        <th style={{ padding: '12px' }}>Check Out</th>
                        <th style={{ padding: '12px' }}>Total Hours</th>
                        <th style={{ padding: '12px' }}>Status</th>
                    </tr>
                </thead>
                <tbody>
                    {filteredRecords.length > 0 ? (
                        filteredRecords.map((record, index) => (
                            <tr key={index}>
                                <td style={{ padding: '10px' }}>{record.userId?.name || 'N/A'}</td>
                                <td style={{ padding: '10px' }}>{record.userId?.department || 'N/A'}</td>
                                <td style={{ padding: '10px' }}>{new Date(record.date).toLocaleDateString()}</td>
                                <td style={{ padding: '10px' }}>{record.checkInTime}</td>
                                <td style={{ padding: '10px' }}>{record.checkOutTime || 'Active'}</td>
                                <td style={{ padding: '10px' }}>{record.totalHours ? `${record.totalHours}h` : '-'}</td>
                                <td style={{ padding: '10px', color: getStatusColor(record.status), fontWeight: 'bold' }}>
                                    {record.status}
                                </td>
                            </tr>
                        ))
                    ) : (
                        <tr><td colSpan="7" style={{ padding: '20px' }}>No records found matching filters.</td></tr>
                    )}
                </tbody>
            </table>
        </div>
    );
};

export default ManagerDashboard;