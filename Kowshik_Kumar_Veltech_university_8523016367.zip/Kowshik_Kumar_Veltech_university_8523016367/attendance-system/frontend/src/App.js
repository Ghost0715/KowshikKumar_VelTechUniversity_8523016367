import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import ManagerDashboard from './components/ManagerDashboard';
import Profile from './components/Profile'; 

function App() {
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [role, setRole] = useState(localStorage.getItem('role'));

  const onLoginSuccess = (userToken, userRole) => {
    setToken(userToken);
    setRole(userRole);
  };
  if (!token) {
    return <Login onLogin={onLoginSuccess} />;
  }

  return (
    <Router>
      <Routes>
        {/* Profile Page is accessible to both roles */}
        <Route path="/profile" element={<Profile />} />

        {/* Role-Based Dashboard Redirection */}
        <Route 
          path="/" 
          element={
            role === 'manager' ? <ManagerDashboard /> : <Dashboard />
          } 
        />

        {/* Catch-all route to redirect back to home */}
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </Router>
  );
}

export default App;